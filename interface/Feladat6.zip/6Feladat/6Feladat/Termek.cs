﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6Feladat
{
    public abstract class Termek
    {
        private string nev;
        protected int egysegAr;

        public string Nev
        {
            get { return nev; }
        }

        public Termek(string nev, int egysegAr)
        {
            this.nev = nev;
            this.egysegAr = egysegAr;
        }

        public abstract int MennyibeKerul();
        public abstract override string ToString();
    }
}
