﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _6Feladat
{
    public class Vegyesbolt
    {
        private List<Termek> termekek;

        public Vegyesbolt()
        {
            termekek = new List<Termek>();
        }

        public void HozzaadTermek(Termek termek)
        {
            termekek.Add(termek);
        }

        public static void Bevasarlok(string eleresiUt, Vegyesbolt bolt)
        {
            try
            {
                string[] sorok = File.ReadAllLines(eleresiUt);
                foreach (string sor in sorok)
                {
                    string[] adatok = sor.Split(';');
                    string nev = adatok[0];
                    int egysegAr = int.Parse(adatok[1]);
                    double mennyiseg = double.Parse(adatok[2]);

                    if (nev.ToLower() == "salata")
                    {
                        Salata salata = new Salata((int)mennyiseg, egysegAr);
                        bolt.HozzaadTermek(salata);
                    }
                    else if (nev.ToLower() == "paradicsom")
                    {
                        RohadtParadicsom paradicsom = new RohadtParadicsom(mennyiseg, egysegAr);
                        bolt.HozzaadTermek(paradicsom);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba történt: {ex.Message}");
            }
        }


        public void Mivanakosaramban()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("kosar.txt"))
                {
                    foreach (Termek termek in termekek)
                    {
                        sw.WriteLine($"{termek.ToString()} {(termek is IAkciozhato ? $"- Akcios ar: {((IAkciozhato)termek).AkciosAr()} Ft" : "")}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Hiba történt: {ex.Message}");
            }
        }
    }
}
