﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6Feladat
{
    public class Salata : Termek
    {
        private int darab;

        public Salata(int darab, int egysegAr) : base("salata", egysegAr)
        {
            this.darab = darab;
        }

        public override int MennyibeKerul()
        {
            return darab * egysegAr;
        }

        public override string ToString()
        {
            return $"{darab} db {Nev} - {MennyibeKerul()} Ft";
        }
    }
}
