﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6Feladat
{
    public class RohadtParadicsom : Termek, IAkciozhato
    {
        private double tomeg;

        public RohadtParadicsom(double tomeg, int egysegAr) : base("rohadt paradicsom", egysegAr)
        {
            this.tomeg = tomeg;
        }

        public override int MennyibeKerul()
        {
            return (int)Math.Round(tomeg * egysegAr);
        }

        public int AkciosAr()
        {
            return (int)Math.Round(0.8 * MennyibeKerul());
        }

        public override string ToString()
        {
            return $"{tomeg} kg {Nev} - {MennyibeKerul()} Ft";
        }
    }
}
