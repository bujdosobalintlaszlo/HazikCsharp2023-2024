﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat8
{
    class Egyagyas : Szoba
    {
        public Egyagyas() : base(1)
        {
        }

        public override void atkoltozik(Szoba celSzoba, int emberSzam)
        {
            if (celSzoba is Ketagyas || celSzoba is Lakosztaly)
            {
                if (emberSzam <= celSzoba.lakok - celSzoba.lakok)
                {
                    this.kikoltozik(emberSzam);
                    celSzoba.lakok += emberSzam;
                }
                else
                {
                    Console.WriteLine("Nincs elég szabad hely a célszobában!");
                }
            }
            else
            {
                Console.WriteLine("Csak Ketagyas vagy Lakosztaly típusú szobába lehet átköltözni!");
            }
        }
        public override string ToString() =>  $"Egyágyas szoba - {base.ToString()}";
    }
}
