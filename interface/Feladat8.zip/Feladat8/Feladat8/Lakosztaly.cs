﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat8
{
    class Lakosztaly : Szoba
    {
        public Lakosztaly(int lakok) : base(lakok)
        {
           
        }

        public override void atkoltozik(Szoba celSzoba, int emberSzam)
        {
            Console.WriteLine("Lakosztályból nem lehet költözni!");
        }

        public override string ToString() => $"Lakosztály - {base.ToString()}";
        
    }
}
