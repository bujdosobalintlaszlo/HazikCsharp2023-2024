﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Feladat8
{
    class Panzio
    {
        static List<Szoba> szobak = new List<Szoba>();
        static void szobatKiad(string filePath)
        {
                StreamReader r = new StreamReader(filePath);
                while (!r.EndOfStream)
                {
                    string[] sor = r.ReadLine().Split(' ');
                    if (sor[0] == "egyagyas")
                    {
                        szobak.Add(new Egyagyas());
                    }
                    else if (sor[0] == "ketagyas")
                    {
                        szobak.Add(new Ketagyas());
                    }
                    else if (sor[0] == "lakosztaly")
                    {
                        szobak.Add(new Lakosztaly(int.Parse(sor[1])));
                    }
                }
                r.Close();
        }
        static void berel()
        {
            foreach (var szoba in szobak)
            {
                if (szoba is Ketagyas)
                {
                    ((Kedvezmenyes)szoba).kedvezmenytKer();
                }
                Console.WriteLine(szoba);
            }
        }
        public void futtat(string fp)
        {
            szobatKiad(fp);
            berel();
        }
    }
}
