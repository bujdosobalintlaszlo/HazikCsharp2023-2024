﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat8
{
    interface Arak
    {
        const int EGYAGYAS = 8000;
        const int KETAGYAS = 12000;
    }
}
