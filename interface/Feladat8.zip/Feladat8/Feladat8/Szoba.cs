﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat8
{
    abstract class Szoba : Arak
    {
        public int berletiDij;
        public int fekvoHely;
        public int lakok;
        protected Szoba(int lakok)
        {
;
            this.lakok = lakok;
            this.fekvoHely = lakok;
            this.berletiDij = fekvoHely > 2 ? Arak.KETAGYAS * lakok : (fekvoHely == 2 ? Arak.KETAGYAS : Arak.EGYAGYAS);
        }

        public abstract void atkoltozik(Szoba celSzoba, int emberSzam);
        public void kikoltozik(int emberSzam) => lakok=-emberSzam >= 0 ? lakok -= emberSzam : lakok;
        public override string ToString() => $"Fekvőhelyek: {fekvoHely}, Lakók: {lakok}, Bérleti díj: {berletiDij}";
    }
}
