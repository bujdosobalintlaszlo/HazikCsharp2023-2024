﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat8
{
    class Ketagyas : Szoba, Kedvezmenyes
    {
        public Ketagyas() : base(2)
        {
        }

        public override void atkoltozik(Szoba celSzoba, int emberSzam)
        {
            if (celSzoba is Lakosztaly)
            {
                if (emberSzam <= celSzoba.fekvoHely - celSzoba.lakok)
                {
                    this.kikoltozik(emberSzam);
                    celSzoba.lakok += emberSzam;
                }
                else
                {
                    Console.WriteLine("Nincs elég szabad hely a célszobában!");
                }
            }
            else
            {
                Console.WriteLine("Csak Lakosztaly típusú szobába lehet átköltözni!");
            }
        }

        public void kedvezmenytKer()
        {
            if (lakok == 1)
            {
                berletiDij = Arak.EGYAGYAS;
                Console.WriteLine("Kedvezményt kért a kétágyas szobára.");
            }
        }
        public override string ToString() => $"Kétágyas szoba - {base.ToString()}";
    }
}
