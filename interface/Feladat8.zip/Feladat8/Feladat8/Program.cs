﻿using System;
using Feladat8;

namespace Feladat8
{
    class Program
    {
        static void Main(string[] args)
        {
            Panzio pan = new Panzio();
            pan.futtat("inp.txt");
        }
    }
}