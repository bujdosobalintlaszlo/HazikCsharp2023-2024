﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarvellIA {
    abstract class Busszuallo: ISzurperhos {
        private double szuperEro;
        private bool vanEGyengesege;

        public double SzuperEro { get; set; }
        public bool VanEGyengesege { get; set; }

        public override string ToString() => ((vanEGyengesege)?"Van gyengesege":"Nincs gyengesege")+"Ero: "+szuperEro;
        

        protected Busszuallo(double szuperEro, bool vanEGyengesege) {
            this.szuperEro = szuperEro;
            this.vanEGyengesege = vanEGyengesege;
        }

        abstract public bool megmentiAVilagot();

        public bool legyoziE(ISzurperhos hos) => (vanEGyengesege && szuperEro > hos.mekkoraAzEreje()) || hos.GetType().Name == "Batman" && hos.mekkoraAzEreje()*2 > szuperEro;
        
        
        public int mekkoraAzEreje() => (int)this.szuperEro;
        
    }
}
