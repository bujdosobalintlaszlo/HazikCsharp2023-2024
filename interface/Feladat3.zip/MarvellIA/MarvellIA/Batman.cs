﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarvellIA
{
    class Batman : ISzurperhos,IMilliardos
    {
        double lelemenyesseg;

        public Batman()
        {
            lelemenyesseg = 100;
        }

        public Batman(double lelemenyesseg)
        {
            this.lelemenyesseg = lelemenyesseg;
        }

        public int mekkoraAzEreje()
        {
            return (int)(lelemenyesseg * 2);
        }

        public bool legyoziE(ISzurperhos sz)
        {
            return lelemenyesseg > sz.mekkoraAzEreje(); 
        }

        public void kutyutKeszit()
        {
            lelemenyesseg += 50;
        }

        public override string ToString()
        {
            return $"Batman lelemenyesseg:{lelemenyesseg}";
        }
    }
}
