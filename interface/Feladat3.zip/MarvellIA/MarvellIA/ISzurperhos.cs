﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarvellIA {
    interface ISzurperhos {
        bool legyoziE(ISzurperhos hos);
        int mekkoraAzEreje();
    }
}
