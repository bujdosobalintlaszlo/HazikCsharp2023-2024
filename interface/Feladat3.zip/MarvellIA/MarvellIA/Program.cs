﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarvellIA {
    class Program {
        static void Main(string[] args) {
            Vasember v = new Vasember();
            Batman b = new Batman();
            Console.WriteLine(v.ToString());
            Console.WriteLine(b.ToString());
            for (int i = 0; i < 1000000; i++)
            {
                b.kutyutKeszit();
            }
            if (b.legyoziE(v))
            {
                Console.WriteLine("hehe - b w");
            }
            else if (v.legyoziE(b))
            {
                Console.WriteLine("haha - v w");
            }
            else
            {
                Console.WriteLine("L");
            }
            Console.ReadLine();
        }
    }
}
