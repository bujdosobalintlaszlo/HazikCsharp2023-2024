﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarvellIA
{
    class Vasember : Busszuallo, IMilliardos
    {
        private static Random r = new Random();
        public Vasember(double szuperEro = 150, bool vanEGyengesege = true) : base(szuperEro, vanEGyengesege)
        {

        }
        override public bool megmentiAVilagot()
        {
            return SzuperEro > 1000;
        }
        public void kutyutKeszit() => SzuperEro += r.NextDouble()*10;
        

        public override string ToString() => $"Vasember {base.ToString()}";
        
    }
}
