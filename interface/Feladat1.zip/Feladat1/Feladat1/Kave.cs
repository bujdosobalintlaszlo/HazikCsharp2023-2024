﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat1
{
    class Kave : Arlap
    {
        bool habosE;

        public Kave(bool habosE)
        {
            this.habosE = habosE;
        }
        public double mennyibeKerul() => habosE ? Arlap.CSESZEKAVE*1.5 : Arlap.CSESZEKAVE;
        public override string? ToString() => habosE ? $"habos kávé {mennyibeKerul()}ft" : $"nem habos kávé {mennyibeKerul()}ft";
    }
}
