﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat1
{
    class Pogacsa : Peksutemeny
    {
        public Pogacsa(double mennyiseg, double alapar) : base(mennyiseg, alapar)
        {
        }
        public override void megkostol() => mennyiseg /= 2;
        public override string? ToString() => $"pogácsa - {base.ToString()}";
    }
}
