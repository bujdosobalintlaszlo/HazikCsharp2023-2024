﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat1
{
    interface Arlap
    {
        double mennyibeKerul();
        const int CSESZEKAVE = 180;
    }
}
