﻿using System;

namespace Feladat1
{
    class Program
    {
        static void Main()
        { 
            Pekseg p = new Pekseg();
            p.futtat("inp.txt");
        }
    }
}
