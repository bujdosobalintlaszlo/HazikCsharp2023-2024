﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Feladat1
{
    class Pekseg
    {
        static List<Arlap> arlap = new List<Arlap>();

        static void vasarlok(string filePath)
        {
            StreamReader r = new StreamReader(filePath);
            while(!r.EndOfStream)
            {
                string[] flSor = r.ReadLine().Split(' ');
                if (flSor[0] is "Pogacsa")
                {
                    arlap.Add(new Pogacsa(int.Parse(flSor[1]), int.Parse(flSor[2])));
                }
                else if (flSor[0] is "Kave")
                {
                    arlap.Add(new Kave(flSor[1] == "habos" ? true : false)) ;
                }
            }
            r.Close();
        }
        static void etelLeltar()
        {
            StreamWriter w = new StreamWriter("leltar.txt");
            arlap.ForEach(v =>
            {
                if (v.GetType().Name == "Pogacsa")
                {
                    w.WriteLine(((Pogacsa)v).ToString());
                }
            });
        }
        public void futtat(string filePath)
        {
            vasarlok(filePath);
            etelLeltar();
        }
    }
}
