﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat1
{
    abstract class Peksutemeny : Arlap
    {
        protected double mennyiseg;
        double alapar;
        protected Peksutemeny(double mennyiseg, double alapar)
        {
            this.mennyiseg = mennyiseg;
            this.alapar = alapar;
        }
        public abstract void megkostol();
        public double mennyibeKerul() => alapar * mennyiseg;
        public override string? ToString() => $"{mennyiseg}db - {mennyibeKerul()}Ft.";
    }
}
