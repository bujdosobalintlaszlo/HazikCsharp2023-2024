﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2Feladat
{
    class Robogo : Jarmu, KisGepjarmu
    {
        int maxSebesseg;

        public Robogo(int maxSebesseg,string rendszam,int jarmuSebesseg) : base(jarmuSebesseg,rendszam)
        {
            this.maxSebesseg = maxSebesseg;
        }

        override public bool gyorshajtottE(int sebessegKorlat)
        {
            if (jarmuSebesseg > maxSebesseg)
            {
                return true;
            }
            return false;
        }
        public bool haladhatItt(int sebesseg)
        {
            if (maxSebesseg > jarmuSebesseg)
            {
                return false;
            }
            return true;
        }

        public override string ToString() => $"Robogo: {base.ToString()}";
    }
}
