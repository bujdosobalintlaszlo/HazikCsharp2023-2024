﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2Feladat
{
    class AudiS8 : Jarmu
    {
        bool lezerblokkolo;

        public AudiS8(bool lezerblokkolo,string rendszam,int jarmuSebesseg) : base(jarmuSebesseg,rendszam)
        {
            this.lezerblokkolo = lezerblokkolo;
        }

        override public bool gyorshajtottE(int sebesseg)
        {
            if (lezerblokkolo)
            {
                return false;
            }
            else if (jarmuSebesseg < sebesseg)
            {
                return false;
            }
            return false;
        }

        public override string ToString()
        {
            return $"Audi: {base.ToString()}";
        }
    }
}
