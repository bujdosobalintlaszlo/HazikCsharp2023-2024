﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _2Feladat
{
    class Orszagut
    {
        public static List<Jarmu> jarmuvek = new List<Jarmu>();

        static void jarmuvekJonnek(string eleresiUtvonal)
        {
            StreamReader r = new StreamReader($"{eleresiUtvonal}.txt");
            while (!r.EndOfStream)
            {
                List<string> sor = r.ReadLine().Split(';').ToList();
                if (sor[0] == "robogo")
                {
                    Robogo rob = new Robogo(int.Parse(sor[3]), sor[1], int.Parse(sor[2]));
                    jarmuvek.Add(rob);
                }
                else
                {
                    AudiS8 au = new AudiS8(bool.Parse(sor[3]),sor[1],int.Parse(sor[2]));
                    jarmuvek.Add(au);
                }
            }
        }
        static void kiketMertunkBe()
        {
            StreamWriter w = new StreamWriter("buntetes.txt");
            jarmuvek.ForEach(x => {
                if (x.GetType().Name == "Robogo")
                {
                    w.WriteLine($"{x.ToString()}, gyorshajtott-e? -> {x.gyorshajtottE(x.jarmuSebesseg)}");
                }
                else 
                { 
                
                }
            });
        }
    }
        
}
