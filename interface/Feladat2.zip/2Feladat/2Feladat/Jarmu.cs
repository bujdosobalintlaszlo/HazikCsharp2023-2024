﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2Feladat
{
    abstract class Jarmu
    {
        public int jarmuSebesseg;
        string rendszam;

        protected Jarmu(int katSebesseg, string rendszam)
        {
            this.jarmuSebesseg = katSebesseg;
            this.rendszam = rendszam;
        }
        abstract public bool gyorshajtottE(int sebessegKorlat);

        public override string ToString() => $"{rendszam} - {jarmuSebesseg}km/h";
        
    }
}
